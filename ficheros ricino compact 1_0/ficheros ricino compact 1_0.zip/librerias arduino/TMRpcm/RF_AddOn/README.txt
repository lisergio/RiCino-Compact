

These files are addon files to enable PCM/WAV streaming using NRF24L01 radio modules.


To enable:

1. Copy the 'pcmRX' folder to your Arduino library folder.

2. Copy the two files in the 'pcmRF' folder to the main TMRpcm folder.


3. Open up and run the two example files in streamingExamples folder


The transmitter/streamer was tested using an Arduino Mega, and uses interrupt 5 (Pin 18) connected to the radio module interrupt pin.


Details at tmrh20.blogspot.com